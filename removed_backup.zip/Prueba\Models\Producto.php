class Product {
    public function getAllProducts() {
        // Simulación de datos (en producción, usa una base de datos real)
        return [
            ['id' => 1, 'name' => 'Producto A', 'price' => 10.00],
            ['id' => 2, 'name' => 'Producto B', 'price' => 15.50],
        ];
    }
}

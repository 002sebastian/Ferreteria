require_once 'controllers/ProductController.php';
$controller = new ProductController();
$controller->index();
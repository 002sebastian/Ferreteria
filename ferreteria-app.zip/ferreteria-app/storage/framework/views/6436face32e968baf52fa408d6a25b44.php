<?php if($errors->any()): ?>
  <div class="alert">
    <strong>Corrige los siguientes campos:</strong>
    <ul style="margin:6px 0 0 18px;">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($e); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
<?php endif; ?>

<div class="grid">
  
  <div class="field">
    <label for="id_cliente">ID Cliente (entero)</label>
    <input type="number" id="id_cliente" name="id_cliente"
           value="<?php echo e(old('id_cliente', $cliente->id_cliente ?? '')); ?>"
           <?php if(isset($cliente)): ?> readonly <?php endif; ?>>
    <?php $__errorArgs = ['id_cliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="error"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>

  <div class="field">
    <label for="nombre">Nombre</label>
    <input type="text" id="nombre" name="nombre" value="<?php echo e(old('nombre', $cliente->nombre ?? '')); ?>">
    <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="error"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>

  <div class="field">
    <label for="rut">RUT</label>
    <input type="text" id="rut" name="rut" value="<?php echo e(old('rut', $cliente->rut ?? '')); ?>">
    <?php $__errorArgs = ['rut'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="error"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>

  <div class="field">
    <label for="telefono">Teléfono</label>
    <input type="text" id="telefono" name="telefono" value="<?php echo e(old('telefono', $cliente->telefono ?? '')); ?>">
    <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="error"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>

  
  <div class="field">
    <label for="email">Email</label>
    <input type="text" id="email" name="email" value="<?php echo e(old('email', $cliente->email ?? '')); ?>">
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="error"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>

  <div class="field">
    <label for="id_ubicacion">Ubicación (opcional)</label>
    <select id="id_ubicacion" name="id_ubicacion">
      <option value="">(Sin ubicación)</option>
      <?php
        // $ubicaciones debe venir desde create/edit
        $sel = old('id_ubicacion', $cliente->id_ubicacion ?? '');
      ?>
      <?php $__currentLoopData = ($ubicaciones ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($u->id_ubicacion); ?>" <?php echo e((string)$sel === (string)$u->id_ubicacion ? 'selected' : ''); ?>>
          #<?php echo e($u->id_ubicacion); ?> — <?php echo e($u->referencia); ?>

        </option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php $__errorArgs = ['id_ubicacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="error"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php if(empty($ubicaciones) || ($ubicaciones ?? collect())->isEmpty()): ?>
      <small class="btn-ghost">No hay ubicaciones cargadas aún.</small>
    <?php endif; ?>
  </div>

  <div class="field">
    <label for="fecha_creacion">Fecha de creación</label>
    <input type="date" id="fecha_creacion" name="fecha_creacion"
           value="<?php echo e(old('fecha_creacion', $cliente->fecha_creacion ?? '')); ?>"
           placeholder="YYYY-MM-DD">
    <small class="btn-ghost">Si lo dejas vacío, se pondrá la fecha de hoy automáticamente al crear.</small>
    <?php $__errorArgs = ['fecha_creacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="error"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
</div>
<?php /**PATH C:\Ferreteria\ferreteria-app\resources\views/cliente/_form.blade.php ENDPATH**/ ?>
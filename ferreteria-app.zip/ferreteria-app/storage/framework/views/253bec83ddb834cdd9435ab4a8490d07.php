

<?php $__env->startSection('content'); ?>
  <div class="card">
    <div class="card-header">
      <h2 style="margin:0;">Clientes</h2>
      <a class="btn btn-primary" href="<?php echo e(route('clientes.create')); ?>">+ Nuevo cliente</a>
    </div>

    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Nombre</th>
          <th>RUT</th>
          <th>Teléfono</th>
          <th>Email</th>
          <th>Ubicación</th>
          <th>Fecha creación</th>
          <th style="width:220px;">Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td><?php echo e($c->id_cliente); ?></td>
            <td><?php echo e($c->nombre); ?></td>
            <td><?php echo e($c->rut); ?></td>
            <td><?php echo e($c->telefono); ?></td>
            <td><?php echo e($c->email); ?></td>
            <td><?php echo e($c->id_ubicacion ?? '—'); ?></td>
            <td><?php echo e($c->fecha_creacion); ?></td>
            <td class="actions">
              <a class="btn" href="<?php echo e(route('clientes.edit', $c->id_cliente)); ?>">Editar</a>
              <form method="POST" action="<?php echo e(route('clientes.destroy', $c->id_cliente)); ?>" onsubmit="return confirm('¿Eliminar cliente?');">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button class="btn btn-danger" type="submit">Eliminar</button>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="8" class="btn-ghost">No hay clientes</td></tr>
        <?php endif; ?>
      </tbody>
    </table>

    <div style="margin-top:12px;">
      <?php echo e($clientes->links()); ?>

    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Ferreteria\ferreteria-app\resources\views/cliente/index.blade.php ENDPATH**/ ?>
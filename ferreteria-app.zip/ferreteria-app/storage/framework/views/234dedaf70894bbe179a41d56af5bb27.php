

<?php $__env->startSection('content'); ?>
  <?php if($errors->any()): ?>
    <div class="alert">
      <strong>Errores:</strong>
      <ul style="margin:6px 0 0 18px;">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($e); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  <?php endif; ?>
  <?php if(session('ok')): ?> <div class="alert"><?php echo e(session('ok')); ?></div> <?php endif; ?>

  <div class="card">
    <div class="card-header">
      <h2 style="margin:0;">Confirmar compra</h2>
      <a class="btn" href="<?php echo e(route('venta.index')); ?>">Volver al carrito</a>
    </div>

    <div class="grid">
      <div class="card" style="border-color:#e5e7eb;">
        <h3 style="margin-top:0;">Resumen</h3>
        <table>
          <thead>
            <tr><th>Producto</th><th>Cant.</th><th>Precio</th><th>Subtotal</th></tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php $line = $it['precio'] * $it['cantidad']; ?>
              <tr>
                <td><?php echo e($it['nombre']); ?></td>
                <td><?php echo e($it['cantidad']); ?></td>
                <td>$<?php echo e(number_format($it['precio'],2)); ?></td>
                <td>$<?php echo e(number_format($line,2)); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>

        <div style="margin-top:10px; text-align:right;">
          <div>Subtotal: <strong>$<?php echo e(number_format($resumen['subtotal'],2)); ?></strong></div>
          <div>IVA: <strong>$<?php echo e(number_format($resumen['ivaTotal'],2)); ?></strong></div>
          <div>Total: <strong>$<?php echo e(number_format($resumen['total'],2)); ?></strong></div>
        </div>
      </div>

      <div class="card" style="border-color:#e5e7eb;">
        <h3 style="margin-top:0;">Datos de factura</h3>
        <form method="POST" action="<?php echo e(route('venta.facturar')); ?>">
          <?php echo csrf_field(); ?>

          <div class="field">
            <label for="id_cliente">Cliente (opcional)</label>
            <select id="id_cliente" name="id_cliente">
              <option value="">(Sin cliente)</option>
              <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($c->id_cliente); ?>"><?php echo e($c->nombre); ?> (#<?php echo e($c->id_cliente); ?>)</option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>

          <div class="field">
            <label for="id_forma_pago">Forma de pago (opcional)</label>
            <select id="id_forma_pago" name="id_forma_pago">
              <option value="">(Sin pago registrado)</option>
              <?php $__currentLoopData = $formasPago; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($f->id_forma_pago); ?>"><?php echo e($f->forma); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <small class="btn-ghost">Si eliges forma de pago, crearemos un registro en <em>detalles_de_pago</em> con el total.</small>
          </div>

          <div style="margin-top:12px; display:flex; gap:10px;">
            <button class="btn btn-primary" type="submit">Facturar</button>
            <a class="btn" href="<?php echo e(route('venta.index')); ?>">Cancelar</a>
          </div>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Ferreteria\ferreteria-app\resources\views/venta/checkout.blade.php ENDPATH**/ ?>
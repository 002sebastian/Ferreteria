

<?php $__env->startSection('content'); ?>
  <?php if(session('ok')): ?> <div class="alert"><?php echo e(session('ok')); ?></div> <?php endif; ?>

  <div class="card">
    <div class="card-header">
      <h2 style="margin:0;">Carrito</h2>
      <a class="btn" href="<?php echo e(route('productos.index')); ?>">Seguir comprando</a>
      <a class="btn btn-primary" href="<?php echo e(route('venta.checkout')); ?>">Facturar</a>
    </div>

    <form method="POST" action="<?php echo e(route('venta.actualizar')); ?>">
      <?php echo csrf_field(); ?>
      <table>
        <thead>
          <tr>
            <th>Producto</th>
            <th>Precio</th>
            <th>IVA %</th>
            <th>Cantidad</th>
            <th>Subtotal</th>
            <th style="width:140px;">Acciones</th>
          </tr>
        </thead>
        <tbody>
          <?php $subtotal=0; $ivaTotal=0; ?>
          <?php $__empty_1 = true; $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
              $line = $it['precio'] * $it['cantidad'];
              $subtotal += $line;
              $ivaTotal += $line * (($it['iva'] ?? 0)/100);
            ?>
            <tr>
              <td><?php echo e($it['nombre']); ?></td>
              <td>$<?php echo e(number_format($it['precio'],2)); ?></td>
              <td><?php echo e($it['iva']); ?></td>
              <td>
                <input type="number" name="items[<?php echo e($id); ?>]" value="<?php echo e($it['cantidad']); ?>" min="1" style="width:90px;">
              </td>
              <td>$<?php echo e(number_format($line,2)); ?></td>
              <td class="actions">
                <button class="btn" type="submit">Actualizar</button>
                <form method="POST" action="<?php echo e(route('venta.quitar')); ?>">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="id_producto" value="<?php echo e($id); ?>">
                  <button class="btn btn-danger" type="submit">Quitar</button>
                </form>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="6">Carrito vacío</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </form>

    <?php $total = $subtotal + $ivaTotal; ?>
    <div style="margin-top:10px; text-align:right;">
      <div>Subtotal: <strong>$<?php echo e(number_format($subtotal,2)); ?></strong></div>
      <div>IVA: <strong>$<?php echo e(number_format($ivaTotal,2)); ?></strong></div>
      <div>Total: <strong>$<?php echo e(number_format($total,2)); ?></strong></div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Ferreteria\ferreteria-app\resources\views/venta/index.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
  <?php if(session('ok')): ?> <div class="alert"><?php echo e(session('ok')); ?></div> <?php endif; ?>

  <div class="card">
    <div class="card-header">
      <h2 style="margin:0;">Productos</h2>
      <a class="btn" href="<?php echo e(route('venta.index')); ?>">Ver carrito</a>
    </div>

    <div class="grid" style="display:grid; grid-template-columns:repeat(auto-fit,minmax(240px,1fr)); gap:16px;">
      <?php $__empty_1 = true; $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card" style="border-color:#e5e7eb;">
          <div style="font-weight:700;"><?php echo e($p->nombre); ?></div>
          <div style="color:#64748b; font-size:14px;">Código: <?php echo e($p->codigo ?? '—'); ?></div>
          <div style="margin-top:6px;">Precio: <strong>$<?php echo e(number_format($p->precio_venta,2)); ?></strong></div>
          <div style="font-size:14px; color:#64748b;">IVA: <?php echo e($p->categoria?->iva ?? 0); ?>%</div>
          <form method="POST" action="<?php echo e(route('venta.agregar')); ?>" style="margin-top:10px; display:flex; gap:8px; align-items:center;">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id_producto" value="<?php echo e($p->id_producto); ?>">
            <input type="number" name="cantidad" value="1" min="1" style="width:90px;">
            <button class="btn btn-primary" type="submit">Agregar</button>
          </form>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div>No hay productos.</div>
      <?php endif; ?>
    </div>

    <div style="margin-top:12px;">
      <?php echo e($productos->links()); ?>

    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Ferreteria\ferreteria-app\resources\views/producto/index.blade.php ENDPATH**/ ?>
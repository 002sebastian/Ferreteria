

<?php $__env->startSection('content'); ?>
  <div class="card">
    <div class="card-header">
      <h2 style="margin:0;">Nuevo cliente</h2>
      <a class="btn" href="<?php echo e(route('clientes.index')); ?>">Volver</a>
    </div>

    <form method="POST" action="<?php echo e(route('clientes.store')); ?>">
      <?php echo csrf_field(); ?>
      <?php echo $__env->make('cliente._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      <div style="margin-top:14px; display:flex; gap:10px;">
        <button class="btn btn-primary" type="submit">Guardar</button>
        <a class="btn" href="<?php echo e(route('clientes.index')); ?>">Cancelar</a>
      </div>
    </form>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Ferreteria\ferreteria-app\resources\views/cliente/create.blade.php ENDPATH**/ ?>
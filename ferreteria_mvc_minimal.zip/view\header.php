<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🏪 Ferretería MVC</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background: #f4f4f4; }
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        header { background: #2c3e50; color: white; padding: 1rem; border-radius: 5px; margin-bottom: 20px; }
        nav a { color: white; text-decoration: none; margin-right: 15px; }
        .alert { padding: 10px; margin: 10px 0; border-radius: 5px; }
        .success { background: #d4edda; color: #155724; }
        .error { background: #f8d7da; color: #721c24; }
        table { width: 100%; border-collapse: collapse; background: white; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #34495e; color: white; }
        .btn { background: #27ae60; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px; display: inline-block; margin: 5px 0; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input, select { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>🏪 Sistema Ferretería</h1>
            <nav>
                <a href="index.php?controller=producto&action=listar">📦 Productos</a>
                <a href="index.php?controller=cliente&action=listar">👥 Clientes</a>
                <a href="index.php?controller=producto&action=agregar">➕ Agregar Producto</a>
            </nav>
        </header>
        <main>
            <?php if (isset($_GET['exito'])): ?>
                <div class="alert success">✅ Operación exitosa!</div>
            <?php endif; ?>
            <?php if (isset($_GET['error'])): ?>
                <div class="alert error">❌ Error en la operación</div>
            <?php endif; ?>

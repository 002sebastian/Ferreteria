        </main>
        <footer style="margin-top: 20px; padding: 20px; text-align: center; color: #666;">
            <p>&copy; <?php echo date('Y'); ?> Ferretería MVC</p>
        </footer>
    </div>
</body>
</html>